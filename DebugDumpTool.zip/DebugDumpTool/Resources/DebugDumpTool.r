//========================================================================================
//  
//  $File: //ai/ai14/devtech/sdk/public/samplecode/MultiArrowTool/Resources/MultiArrowTool.r $
//
//  $Revision: #5 $
//
//  Copyright 1987-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#define PIPL_PLUGIN_NAME "DebugDumpTool"
#include "Plugin.r"

#include "Types.r"

read 'PNGI' (16051, "DebugDumpTool", purgeable)  "DebugDumpTool.png";

// Tool names and tool tip text.
resource 'STR#' (16100, "Tool Strings") {
	{
        "Debug Dump Tool";
	}
};

/** Debug Dump Tool cursor.
*/
resource 'CURS' (16001) {
        $"00 00 00 00"
		$"00 00 01 00"
		$"01 00 01 00"
		$"03 80 1F F0"
        $"03 80 01 00"
		$"01 00 01 00"
		$"00 00 00 00"
		$"00 00 00 00",
        $"00 00 00 00"
		$"00 00 01 00"
		$"01 00 01 00"
		$"03 80 1F F0"
        $"03 80 01 00"
		$"01 00 01 00"
		$"00 00 00 00"
		$"00 00 00 00",
        {7, 7}
};
