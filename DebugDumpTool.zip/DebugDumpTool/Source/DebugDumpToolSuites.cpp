//========================================================================================
//  
//  $File: //ai/ai14/devtech/sdk/public/samplecode/DebugDumpTool/Source/DebugDumpToolSuites.cpp $
//
//  $Revision: #2 $
//
//  Copyright 1987-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "IllustratorSDK.h"
#include "DebugDumpToolSuites.h"

extern "C" {
	AIMenuSuite*				sAIMenu = NULL;
	AIDocumentSuite*			sAIDocument = NULL;
	AIToolSuite*				sAITool = NULL;
	AIUnicodeStringSuite*		sAIUnicodeString = NULL;
	AIPluginSuite*				sAIPlugin = NULL;
	SPBlocksSuite*				sSPBlocks = NULL;
	AIUndoSuite*				sAIUndo = NULL;
	AIArtSuite*					sAIArt = NULL;
	AIRealMathSuite*			sAIRealMath = NULL;
	AIPathSuite*				sAIPath = NULL;
	AIPathStyleSuite*			sAIPathStyle = NULL;
	ADMIconSuite*				sADMIcon = NULL;
	ADMTrackerSuite*			sADMTracker = NULL;
	AIHitTestSuite*				sAIHitTest = NULL;
	AILayerSuite*				sAILayer = NULL;
	AIDictionarySuite*			sAIDictionary = NULL;
	AILiveEffectSuite*			sAILiveEffect = NULL;
	AIArtStyleParserSuite*		sAIArtStyleParser = NULL;
	AIArtStyleSuite*			sAIArtStyle = NULL;
	AIDictionaryIteratorSuite*	sAIDictionaryIterator = NULL;
}

ImportSuite gImportSuites[] = {
	kAIMenuSuite, kAIMenuSuiteVersion, &sAIMenu,
	kAIDocumentSuite, kAIDocumentSuiteVersion, &sAIDocument,
	kAIToolSuite, kAIToolVersion, &sAITool,
	kAIUnicodeStringSuite, kAIUnicodeStringVersion, &sAIUnicodeString,
	kAIPluginSuite, kAIPluginSuiteVersion, &sAIPlugin,
	kSPBlocksSuite, kSPBlocksSuiteVersion, &sSPBlocks,
	kAIUndoSuite, kAIUndoSuiteVersion, &sAIUndo,
	kAIArtSuite, kAIArtVersion, &sAIArt,
	kAIRealMathSuite, kAIRealMathVersion, &sAIRealMath,	
	kAIPathSuite, kAIPathSuiteVersion, &sAIPath,
	kAIPathStyleSuite, kAIPathStyleSuiteVersion, &sAIPathStyle,
	kADMIconSuite, kADMIconSuiteVersion, &sADMIcon,
	kADMTrackerSuite, kADMTrackerSuiteVersion, &sADMTracker,
	kAIHitTestSuite, kAIHitTestSuiteVersion, &sAIHitTest,
	kAILayerSuite, kAILayerSuiteVersion, &sAILayer,
	kAIDictionarySuite, kAIDictionarySuiteVersion, &sAIDictionary,
	kAILiveEffectSuite, kAILiveEffectSuiteVersion, &sAILiveEffect,
	kAIArtStyleParserSuite, kAIArtStyleParserSuiteVersion, &sAIArtStyleParser,
	kAIArtStyleSuite, kAIArtStyleSuiteVersion, &sAIArtStyle,
	kAIDictionaryIteratorSuite, kAIDictionaryIteratorSuiteVersion, &sAIDictionaryIterator,
	nil, 0, nil
};

// End DebugDumpToolSuites.cpp