//========================================================================================
//  
//  $File: //ai/ai14/devtech/sdk/public/samplecode/DebugDumpTool/Source/DebugDumpToolPlugin.h $
//
//  $Revision: #3 $
//
//  Copyright 1987-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __DEBUGDUMPTOOLPLUGIN_H__
#define __DEBUGDUMPTOOLPLUGIN_H__

#include "Plugin.hpp"
#include "SDKDef.h"
#include "SDKAboutPluginsHelper.h"
#include "DebugDumpToolID.h"
#include "DebugDumpToolSuites.h"

/**	Creates a new DebugDumpToolPlugin.
	@param pluginRef IN unique reference to this plugin.
	@return pointer to new DebugDumpToolPlugin.
*/
Plugin* AllocatePlugin(SPPluginRef pluginRef);

/**	Reloads the DebugDumpToolPlugin class state when the plugin is 
	reloaded by the application.
	@param plugin IN pointer to plugin being reloaded.
*/
void FixupReload(Plugin* plugin);

/**	Provides a plugin which demonstrates adding a group of tools to the toolbar.
*/
class DebugDumpToolPlugin : public Plugin
{
public:

	/**	Constructor.
		@param pluginRef IN reference to this plugin.
	*/
	DebugDumpToolPlugin(SPPluginRef pluginRef);

	/**	Destructor.
	*/
	~DebugDumpToolPlugin(){}

	/**	Restores state of DebugDumpToolPlugin during reload.
	*/
	FIXUP_VTABLE_EX(DebugDumpToolPlugin, Plugin);

protected:

	/** Calls Plugin::Message and handles any errors returned.
		@param caller IN sender of the message.
		@param selector IN nature of the message.
		@param message IN pointer to plugin and call information.
		@return kNoErr on success, other ASErr otherwise.
	*/
	virtual ASErr Message(char* caller, char* selector, void *message);

	/**	Calls Plugin::Startup and initialisation functions, such as 
		AddTools and AddMenus.
		@param message IN pointer to plugin and call information.
		@return kNoErr on success, other ASErr otherwise.
	*/
	virtual ASErr StartupPlugin(SPInterfaceMessage* message);

	/**	Performs actions required for menu item selected.
		@param message IN pointer to plugin and call information.
		@return kNoErr on success, other ASErr otherwise.
	*/
	virtual ASErr GoMenuItem(AIMenuMessage* message);

	/**	Sets the platform cursor to the icon for the current tool selected.
		@param message IN pointer to plugin and call information.
		@return kNoErr on success, other ASErr otherwise.
	*/
	virtual ASErr TrackToolCursor(AIToolMessage* message);

	/**	Sets fStartingPoint to location of pointer during mouse down event.
		@param message IN pointer to plugin and call information.
		@return kNoErr on success, other ASErr otherwise.
	*/
	virtual ASErr ToolMouseDown(AIToolMessage* message);

	/**	Draws the art on screen during mouse drag event.
		@param message IN pointer to plugin and call information.
		@return kNoErr on success, other ASErr otherwise.
	*/
	virtual ASErr ToolMouseDrag(AIToolMessage* message);
	
private:

	/**	Menu item handle for about plugin dialog.
	*/
	AIMenuItemHandle fAboutPluginMenu;

	/** Stores handles for each tool.
	*/
	AIToolHandle fToolHandle[4];

	/** Stores h,v location of line/arrow start point.
	*/
	AIRealPoint fStartingPoint;

	/** Stores h,v location of line/arrow end point.
	*/
	AIRealPoint fEndPoint;

	/**	Adds the tools for this plugin to the application toolbar.
		@param message IN pointer to plugin and call information.
		@return kNoErr on success, other ASErr otherwise.
	*/
	ASErr AddTools(SPInterfaceMessage* message);

	/**	Adds the menu items for this plugin to the application UI.
		@param message IN pointer to plugin and call information.
		@return kNoErr on success, other ASErr otherwise.
	*/
	ASErr AddMenus(SPInterfaceMessage* message);

	/**	Sets the cursor displayed in the application to the current selected
		tools cursor.
		@param pluginRef IN reference to this plugin.
		@param nCursorID IN the resource ID of the selected tools cursor.
		@return kNoErr on success, other ASErr otherwise.
	*/
	ASErr SetPlatformCursor(SPPluginRef pluginRef, int nCursorID);

	std::string		GetArtType(AIArtHandle art) const;
	std::string		GetEntryType(AIEntryType type) const;
	void			PrintEntryValue(AIDictionaryRef dictionary, AIDictKey key) const;
	void			DumpArt(AIArtHandle art);
	void			DumpDictionary(AIDictionaryRef dictionary, int depth = 0);
	void			OutputInset(int depth, char suffix = 0);
};

#endif // End DebugDumpToolPlugin.h
