//========================================================================================
//  
//  $File: //ai/ai14/devtech/sdk/public/samplecode/DebugDumpTool/Source/DebugDumpToolSuites.h $
//
//  $Revision: #2 $
//
//  Copyright 1987-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __DEBUGDUMPTOOLSUITES_H__
#define __DEBUGDUMPTOOLSUITES_H__

#include "IllustratorSDK.h"
#include "Suites.hpp"

#include "AIArtStyle.h"
#include "AIArtStyleParser.h"
#include "AILiveEffect.h"

extern	"C"	AIMenuSuite*			sAIMenu;
extern	"C"	AIDocumentSuite*		sAIDocument;
extern	"C"	AIDictionarySuite*		sAIDictionary;
extern	"C"	AIDictionaryIteratorSuite*		sAIDictionaryIterator;
extern	"C"	AIArtStyleSuite*		sAIArtStyle;
extern	"C"	AIArtStyleParserSuite*	sAIArtStyleParser;
extern	"C"	AIHitTestSuite*			sAIHitTest;
extern	"C"	AILayerSuite*			sAILayer;
extern	"C"	AILiveEffectSuite*		sAILiveEffect;
extern	"C"	AIToolSuite*			sAITool;
extern	"C"	AIUnicodeStringSuite*	sAIUnicodeString;
extern	"C"	AIPluginSuite*			sAIPlugin;
extern	"C"	SPBlocksSuite*			sSPBlocks;
extern	"C"	AIUndoSuite*			sAIUndo;
extern	"C"	AIArtSuite*				sAIArt;
extern	"C"	AIRealMathSuite*		sAIRealMath;
extern	"C"	AIPathSuite*			sAIPath;
extern	"C"	AIPathStyleSuite*		sAIPathStyle;
extern	"C"	ADMIconSuite*			sADMIcon;
extern	"C"	ADMTrackerSuite*		sADMTracker;

#endif // End DebugDumpToolSuites.h
