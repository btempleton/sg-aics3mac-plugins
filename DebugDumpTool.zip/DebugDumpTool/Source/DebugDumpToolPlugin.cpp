//========================================================================================
//  
//  $File: //ai/ai14/devtech/sdk/public/samplecode/DebugDumpTool/Source/DebugDumpToolPlugin.cpp $
//
//  $Revision: #5 $
//
//  Copyright 1987-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "IllustratorSDK.h"
#include "DebugDumpToolPlugin.h"

/*
*/
Plugin* AllocatePlugin(SPPluginRef pluginRef)
{
	return new DebugDumpToolPlugin(pluginRef);
}

/*
*/
void FixupReload(Plugin* plugin)
{
	DebugDumpToolPlugin::FixupVTable((DebugDumpToolPlugin*) plugin);
}

/*
*/
DebugDumpToolPlugin::DebugDumpToolPlugin(SPPluginRef pluginRef)
	: Plugin(pluginRef)
{
	strncpy(fPluginName, kDebugDumpToolPluginName, kMaxStringLength);
}

/*
*/
ASErr DebugDumpToolPlugin::Message(char* caller, char* selector, void *message) 
{
	ASErr error = kNoErr;

	try {
		error = Plugin::Message(caller, selector, message);
	}
	catch (ai::Error& ex) {
		error = ex;
	}
	catch (...) {
		error = kCantHappenErr;
	}
	if (error) {
		if (error == kUnhandledMsgErr) {
			// Defined by Plugin.hpp and used in Plugin::Message - ignore.
			error = kNoErr;
		}
		else {
			Plugin::ReportError(error, caller, selector, message);
		}
	}	
	return error;
}

/*
*/
ASErr DebugDumpToolPlugin::StartupPlugin(SPInterfaceMessage* message) 
{
	ASErr error = kNoErr;
	long pluginOptions = 0;	
	
	error = Plugin::StartupPlugin(message);
	if (error) goto error;
	
	error = sAIPlugin->GetPluginOptions(message->d.self, &pluginOptions);
	if (error) goto error;
	
	error = sAIPlugin->SetPluginOptions(message->d.self, pluginOptions | kPluginWantsResultsAutoSelectedOption );
	if (error) goto error;
	
	error = AddTools(message);
	if (error) goto error;

	error = AddMenus(message);
	if (error) goto error;
	
error:
	return error;
}

/*
*/
ASErr DebugDumpToolPlugin::GoMenuItem(AIMenuMessage* message) 
{
	ASErr error = kNoErr;
	if (message->menuItem == this->fAboutPluginMenu) {
		// Pop this plug-in's about box.
		SDKAboutPluginsHelper aboutPluginsHelper;
		aboutPluginsHelper.PopAboutBox(message, "About DebugDumpTool", kSDKDefAboutSDKCompanyPluginsAlertString);
	}	
	return error;
}

/*
*/
ASErr DebugDumpToolPlugin::AddMenus(SPInterfaceMessage* message) 
{
	ASErr error = kNoErr;
	// Add a menu item to the About SDK Plug-ins menu group.
	SDKAboutPluginsHelper aboutPluginsHelper;
	error = aboutPluginsHelper.AddAboutPluginsMenuItem(message, 
				kSDKDefAboutSDKCompanyPluginsGroupName, 
				ai::UnicodeString(kSDKDefAboutSDKCompanyPluginsGroupNameString), 
				"DebugDumpTool...", 
				&fAboutPluginMenu);
	return error;
}

/*
*/
ASErr DebugDumpToolPlugin::AddTools(SPInterfaceMessage* message)
{
	AIErr error = kNoErr;
	AIAddToolData toolData;

	short i;
	char bufftitle[256], firstToolName[256];	
	
	for ( i = 0; i < 1; i++ ) {	
		sADMBasic->GetIndexString( message->d.self, kToolStrings, (i+1), bufftitle, sizeof( bufftitle ) );
							  
		toolData.title = bufftitle;
		toolData.tooltip = bufftitle;					   
	
		toolData.icon = sADMIcon->GetFromResource (  message->d.self, kToolIcons, (i+1) );
		
		if ((sADMIcon->GetType(toolData.icon)) == kUnknown )
			return kNoIconErr;

		if ( i == 0 ) {
            strcpy( firstToolName, toolData.title);
			// New group on tool palette.
			toolData.sameGroupAs = kNoTool;
			// New toolset in new group.
			toolData.sameToolsetAs = kNoTool;			
		}
		else {
			error = sAITool->GetToolNumberFromName( firstToolName, &toolData.sameGroupAs);			
			error = sAITool->GetToolNumberFromName( firstToolName, &toolData.sameToolsetAs);
		}
	
		error = sAITool->AddTool( message->d.self, toolData.title, &toolData, kToolWantsToTrackCursorOption, &fToolHandle[i] );
		
		if (error)
			goto errorTag;
	}

errorTag:
	return error;
}

/*
*/
ASErr DebugDumpToolPlugin::TrackToolCursor(AIToolMessage* message) 
{
	AIErr error = kNoErr;
	short cursorIndex = 1;
	
	if ( message->tool == this->fToolHandle[1] )
		cursorIndex = 2;
	else if ( message->tool == this->fToolHandle[2] )
		cursorIndex = 3;
	else if ( message->tool == this->fToolHandle[3] )
		cursorIndex = 4;
	

	error = this->SetPlatformCursor(message->d.self, ( kCursorID + cursorIndex) );

	return error;
}

#define THROW_EXCEP_IF(error)
#define TRACE _Trace

void TraceInternal(const char *format, va_list argptr) 
{
	const int kBufferSize = 8192;
	static char buf[kBufferSize];
	buf[0] = buf[kBufferSize-1] = 0;

#ifdef _WIN32
	_vsnprintf(buf, sizeof(buf)- 1, format, argptr);
#else
	vsnprintf(buf, sizeof(buf)- 1, format, argptr);
#endif

#ifdef _WIN32
	OutputDebugStringA(buf);
#else
	fprintf(stderr, buf);
#endif
}

void _Trace(const char* format, ...)
{
	va_list argptr;
	va_start(argptr, format);

	TraceInternal(format, argptr);
	va_end(argptr);
}


/*
*/
ASErr DebugDumpToolPlugin::ToolMouseDown(AIToolMessage* message)
{
	ASErr error = kNoErr;

	// we want our initial mouse down to base the drag on later	
	this->fStartingPoint = message->cursor;
	
	const int modifiers = message->event->modifiers;

	if ((modifiers & aiEventModifiers_shiftKey) && (modifiers & aiEventModifiers_optionKey)) {
		TRACE("*** ------ Debug Dump of document dictionary\n");

		AIDictionaryRef dictionary = 0;
		AIErr error = sAIDocument->GetDictionary(&dictionary);
		THROW_EXCEP_IF(error);

		DumpDictionary(dictionary);

		TRACE("--------------------------------------------\n");
	} else if (modifiers & aiEventModifiers_shiftKey) {
		AILayerHandle handle = 0;
		AIErr error = sAILayer->GetCurrentLayer(&handle);
		THROW_EXCEP_IF(error);

		TRACE("*** ------ Debug Dump on layer ");
		TRACE("[");

		ai::UnicodeString name;
		error = sAILayer->GetLayerTitle(handle, name);
		THROW_EXCEP_IF(error);
		
		TRACE(name.as_Platform().c_str());
		TRACE("]\n");

		AIArtHandle layerGroup = 0;
		error = sAIArt->GetFirstArtOfLayer(handle, &layerGroup);
		THROW_EXCEP_IF(error);
		
		DumpArt(layerGroup);
		TRACE("--------------------------------------------\n");
	} else {
		AIRealPoint hitPoint;
		hitPoint.h = static_cast<ASReal>(message->cursor.h);
		hitPoint.v = static_cast<ASReal>(message->cursor.v);

		AILayerHandle layer;
		AIErr error = sAILayer->GetCurrentLayer(&layer);
		THROW_EXCEP_IF(error);

		AIArtHandle layerGroup = 0;
		error = sAIArt->GetFirstArtOfLayer(layer, &layerGroup);
		THROW_EXCEP_IF(error);

		AIHitRef hitData;
		error = sAIHitTest->HitTest(NULL, &hitPoint, kAllHitRequest, &hitData);
		THROW_EXCEP_IF(error);

		if (hitData && sAIHitTest->IsHit(hitData)) {
			AIArtHandle target = sAIHitTest->GetArt(hitData);

			short attribute = 0;
			long attributes = 0;
			AIErr error = sAIArt->GetArtUserAttr(target, kArtPartOfCompound, &attributes);
			THROW_EXCEP_IF(error);

			if (attributes & kArtPartOfCompound)  {	
				short type = 0;
				error = sAIArt->GetArtType(target, &type);
				THROW_EXCEP_IF(error);

				while (type != kCompoundPathArt) {
					error = sAIArt->GetArtParent(target, &target);
					THROW_EXCEP_IF(error);

					error = sAIArt->GetArtType(target, &type);
					THROW_EXCEP_IF(error);
				}
			}

			const std::string type = GetArtType(target);	

			AILayerHandle artLayer = 0;
			error = sAIArt->GetLayerOfArt(target, &artLayer);
			THROW_EXCEP_IF(error);			

			ai::UnicodeString name;
			error = sAILayer->GetLayerTitle(artLayer, name);
			THROW_EXCEP_IF(error);
			const std::string title = name.as_Platform();

			TRACE("*** ------ Debug Dump of 0x%x [%s] on layer '%s' [0x%x]\n", target, type.c_str(), title.c_str(), artLayer);
			
			DumpArt(target);

			TRACE("--------------------------------------------\n");
		}
	}

error:
	return error;
}

/*
*/
ASErr DebugDumpToolPlugin::ToolMouseDrag(AIToolMessage* message)
{
	ASErr error = kNoErr;
error:
	return error;
}

/*
*/
ASErr DebugDumpToolPlugin::SetPlatformCursor(SPPluginRef pluginRef, int nCursorID)
{
	sADMBasic->SetPlatformCursor(pluginRef, nCursorID);
	return kNoErr;
}

////////////////////////////////////////

std::string DebugDumpToolPlugin::GetArtType(AIArtHandle art) const
{
	std::string result;

	short type = 0;
	sAIArt->GetArtType(art, &type);

	switch (type) {
		default:
		case kUnknownArt:
			result = "Unknown";
			break;
		case kGroupArt:
			result = "Group";
			break;
		case kPathArt:
			result = "Path";
			break;
		case kCompoundPathArt:
			result = "Compound Path";
			break;
		case kTextArtUnsupported:
			result = "Text (Unsupported)";
			break;
		case kTextPathArtUnsupported:
			result = "Text Path (Unsupported)";
			break;
		case kTextRunArtUnsupported:
			result = "Text Run (Unsupported)";
			break;
		case kPlacedArt:
			result = "Placed";
			break;
		case kMysteryPathArt:
			result = "Mystery Path";
			break;
		case kRasterArt:
			result = "Raster";
			break;
		case kPluginArt:
			result = "Plugin";
			break;
		case kMeshArt:
			result = "Mesh";
			break;
		case kTextFrameArt:
			result = "Text Frame";
			break;
		case kSymbolArt:
			result = "Symbol";
			break;
		case kForeignArt:
			result = "Foreign";
			break;
		case kLegacyTextArt:
			result = "Legacy Text";
			break;
	}

	return result;
}

std::string DebugDumpToolPlugin::GetEntryType(AIEntryType type) const
{
	std::string result;

	switch (type) {
		case UnknownType:
			result = "Unknown";
			break;
		case IntegerType:
			result = "Integer";
			break;
		case BooleanType:
			result = "Boolean";
			break;
		case RealType:
			result = "Real";
			break;
		case StringType:
			result = "String";
			break;
		case DictType:
			result = "Dictionary";
			break;
		case ArrayType:
			result = "Array";
			break;
		case BinaryType:
			result = "Binary";
			break;
		case PointType:
			result = "Point";
			break;
		case MatrixType:
			result = "Matrix";
			break;
		case PatternRefType:
			result = "Pattern Ref";
			break;
		case BrushPatternRefType:
			result = "Brush Pattern Ref";
			break;
		case CustomColorRefType:
			result = "Custom Color Ref";
			break;
		case GradientRefType:
			result = "Gradient Ref";
			break;
		case PluginObjectRefType:
			result = "Plugin Object Ref";
			break;
		case FillStyleType:
			result = "Fill Style";
			break;
		case StrokeStyleType:
			result = "Stroke Style";
			break;
		case UIDType:
			result = "UID";
			break;
		case UIDREFType:
			result = "UID Ref";
			break;
		case XMLNodeType:
			result = "XML Node";
			break;
		case SVGFilterType:
			result = "SVG Filter";
			break;
		case ArtStyleType:
			result = "Art Style";
			break;
		case SymbolPatternRefType:
			result = "Symbol Pattern";
			break;
		case GraphDesignRefType:
			result = "Graph Design Ref";
			break;
		case BlendStyleType:
			result = "Blend Style";
			break;
		case GraphicObjectType:
			result = "Graphic Object";
			break;
		case UnicodeStringType:
			result = "Unicode String";
			break;
	}

	return result;
}

void DebugDumpToolPlugin::PrintEntryValue(	const AIDictionaryRef dictionary,
												const AIDictKey key) const
{
	AIEntryType type;
	sAIDictionary->GetEntryType(dictionary, key, &type);
	TRACE("= ");

	switch (type) {
		case IntegerType:
			{
				ASInt32 value = 0;
				sAIDictionary->GetIntegerEntry(dictionary, key, &value);
				TRACE("%d", value);
			}
			break;
		case BooleanType:
			{
				ASBoolean value = 0;
				sAIDictionary->GetBooleanEntry(dictionary, key, &value);
				TRACE(value ? "true" : "false");
			}
			break;
		case RealType:
			{
				ASReal value = 0;
				sAIDictionary->GetRealEntry(dictionary, key, &value);
				TRACE("%f", value);
			}
			break;
		case StringType:
			{
				const char* value = 0;
				sAIDictionary->GetStringEntry(dictionary, key, &value);
				TRACE(value);
			}
			break;
		case UnicodeStringType:
			{
				ai::UnicodeString value;
				sAIDictionary->GetUnicodeStringEntry(dictionary, key, value);
				TRACE(value.as_Platform().c_str());
			}
			break;
		case ArrayType:
		case BinaryType:
		case PointType:
		case MatrixType:
		case PatternRefType:
		case BrushPatternRefType:
		case CustomColorRefType:
		case GradientRefType:
		case PluginObjectRefType:
		case FillStyleType:
		case StrokeStyleType:
		case UIDType:
		case UIDREFType:
		case XMLNodeType:
		case SVGFilterType:
		case ArtStyleType:
		case SymbolPatternRefType:
		case GraphDesignRefType:
		case BlendStyleType:
		case GraphicObjectType:
			TRACE("<not implemented>");
			break;
	}
}

void DebugDumpToolPlugin::DumpArt(AIArtHandle art)
{
	AIDictionaryRef dictionary = 0;
	AIErr error = sAIArt->GetDictionary(art, &dictionary);
	THROW_EXCEP_IF(error);

	DumpDictionary(dictionary);

	TRACE(" *** Appearance\n");

	AIArtStyleHandle style = 0;
	error = sAIArtStyle->GetArtStyle(art, &style);
	THROW_EXCEP_IF(error);

	AIStyleParser parser = 0;
	error = sAIArtStyleParser->NewParser(&parser);
	THROW_EXCEP_IF(error);

	error = sAIArtStyleParser->ParseStyle(parser, style);
	THROW_EXCEP_IF(error);

	const long count = sAIArtStyleParser->CountPaintFields(parser);

	for (long i = 0; i < count; i++) {
		AIParserPaintField paintField = 0;
		error = sAIArtStyleParser->GetNthPaintField(parser, i, &paintField);
		THROW_EXCEP_IF(error);

		if (sAIArtStyleParser->IsStroke(paintField)) {
			TRACE(" %d Stroke:\n", (i + 1));
		} else {
			TRACE(" %d Fill:\n", (i + 1));
		}

		const long effectCount = sAIArtStyleParser->CountEffectsOfPaintField(paintField);

		for (long j = 0; j < effectCount; j++) {
			AIParserLiveEffect paintEffect = 0;
			error = sAIArtStyleParser->GetNthEffectOfPaintField(paintField, j, &paintEffect);
			THROW_EXCEP_IF(error);

			AILiveEffectHandle liveEffect = 0;
			error = sAIArtStyleParser->GetLiveEffectHandle(paintEffect, &liveEffect);
			THROW_EXCEP_IF(error);

			const char* effectName;
			error = sAILiveEffect->GetLiveEffectName(liveEffect, &effectName);
			THROW_EXCEP_IF(error);
			
			OutputInset(1);
			TRACE("Effect: \"");
			TRACE(effectName);
			TRACE("\"\n");

			AILiveEffectParameters parameters;
			error = sAILiveEffect->CreateLiveEffectParameters(&parameters);
			THROW_EXCEP_IF(error);

			error = sAIArtStyleParser->GetLiveEffectParams(paintEffect, &parameters);
			THROW_EXCEP_IF(error);

			DumpDictionary(parameters, 2);
		}
	}

	error = sAIArtStyleParser->DisposeParser(parser);
	THROW_EXCEP_IF(error);
}

void DebugDumpToolPlugin::DumpDictionary(AIDictionaryRef dictionary, int depth)
{
	const ASInt32 count = sAIDictionary->Size(dictionary);
	int localDepth = depth;

	if (0 == localDepth) {
		OutputInset(localDepth);
		TRACE("Art dictionary 0x%x - %d entries\n", dictionary, count);
		localDepth++;
	}

	AIDictionaryIterator dictIter;
	sAIDictionary->Begin(dictionary, &dictIter);

	while (!sAIDictionaryIterator->AtEnd(dictIter)) {
		AIDictKey key = sAIDictionaryIterator->GetKey(dictIter);

		AIEntryType type;
		sAIDictionary->GetEntryType(dictionary, key, &type);

		OutputInset(localDepth, '+');
		TRACE("%s [%s]", sAIDictionary->GetKeyString(key), GetEntryType(type).c_str());

		if (DictType == type) {
			AIDictionaryRef subDictionary = 0;
			sAIDictionary->GetDictEntry(dictionary, key, &subDictionary);

			const ASInt32 subCount = sAIDictionary->Size(subDictionary);
			TRACE("%d entries", subCount);
			TRACE("\n");

			DumpDictionary(subDictionary, localDepth + 1);
		} else {
			PrintEntryValue(dictionary, key);

			TRACE("\n");
		}

		sAIDictionaryIterator->Next(dictIter);
	}
}

void DebugDumpToolPlugin::OutputInset(int depth, char suffix)
{
	for (int i = 0; i < (depth * 5); i++) {
		TRACE(" ");
	}

	if (suffix > 0) {
		TRACE("%c", suffix);
	}
}


// End DebugDumpToolPlugin.cpp