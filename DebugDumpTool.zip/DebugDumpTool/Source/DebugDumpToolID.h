//========================================================================================
//  
//  $File: //ai/ai14/devtech/sdk/public/samplecode/MultiArrowTool/Source/MultiArrowToolID.h $
//
//  $Revision: #3 $
//
//  Copyright 1987-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __DEBUGDUMPTOOLID_H__
#define __DEBUGDUMPTOOLID_H__

#define kDebugDumpToolPluginName	"DebugDumpTool"


#define kMyToolIcon				1
#define kCursorID				16000
#define kToolIcons				16050
#define kToolStrings			16100
#define kNoIconErr				'!ico'

#endif // End MultiArrowToolID.h
